//  AT.h – Bibliothek zur Automatisierungtechnik.

#ifndef AT_h // diese Datei ggf. ueberspringen
#define AT_h

#include "Arduino.h"

class Zeitglied
{
   public:
    Zeitglied( );                                  // default constructor; keine Uebergabewerte
    void Update(bool Eingang, long TVerzoegerung); // Funktion, um aktuelles Ausgangssignal zu berechnen
    bool ZeitgliedAusgang;                        // Variable: Ausgangssignal
}; // end class Zeitglied


class RS
{
   public:
  RS( );
    void Update(bool Setzen, bool Ruecksetzen);    
    bool RSAusgang;  
}; // end class RS

#endif
