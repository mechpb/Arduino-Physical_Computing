//  AT.cpp – Bibliothek zur Automatisierungtechnik.

#include "Arduino.h"
#include "AT.h"


// Zeitglied
Zeitglied::Zeitglied()
{
} // end Zeitglied()

void Zeitglied::Update(bool Eingang, long TVerzoegerung)   // Aufruf, um Eingangssignal unt PT zu uebergeben und auszuwerten
{
  static unsigned long ZeitStart;
  unsigned long ZeitJetzt;
  static bool   EingangAlt;

  // Abfrage ob Eingangssignal true; wenn nicht true, Ausgang auf false setzen
  if (! Eingang) {
    ZeitgliedAusgang = false;
  }
  // da Eingang true, jetzt else-Zweig
  else
  { if (ZeitgliedAusgang == true)
      // Eingang true und Einschaltverzoegerungszeit abgelaufen => Ausgang bleibt true, nichts zu tun
    {  }
    // Eingang true, aber vorher war die Einschaltverzoegerungszeit noch nicht erreicht.
    // Pruefen, ob jetzt einzuschalten ist
    else
      // erster Durchlauf, bei dem Eingang true ist? Wenn ja, Startzeit speichern
    { if ((Eingang && (! EingangAlt) )  == true)
      {
        ZeitStart =  millis();
      }
      else
        // jetzt Zeit zum Einschalten?
      { ZeitJetzt =  millis();
        if (ZeitJetzt > (ZeitStart + TVerzoegerung) )
        {
          ZeitgliedAusgang = true;
        }
      }
    }
  }
  // aktuellen Wert des Eingangssignal abspeichern fuer naechsten Durchlauf
  EingangAlt = Eingang;
} // end Zeitglied::Update


// ------------------------------

RS::RS()
{
}
void RS::Update(bool Setzen, bool Ruecksetzen)
{
  if (Setzen) {
    RSAusgang = true;
  }
  if (Ruecksetzen) {
    RSAusgang = false;
  }
} // end RS
